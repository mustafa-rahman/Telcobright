﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PortalApp.ReportHelper
{
    public class SqlHelperIntOut:AbstractSqlHelper{
    public  SqlHelperIntOut(string startDate, string endDate, string groupInterval,
                                    List<string> groupExpressions, List<string> whereExpressions)
    {
        StartDate = startDate;
        EndDate = endDate;
        this.groupInterval = groupInterval;
        this.groupExpressions = groupExpressions;
        this.whereExpressions = whereExpressions;

    }
}
}