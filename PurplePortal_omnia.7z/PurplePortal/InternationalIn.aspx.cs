using MediationModel;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using reports;
using ExportToExcel;
using PortalApp;
using System.Globalization;
using System.IO;
public partial class _DefaultRptIntlIn : System.Web.UI.Page
{
    private int m_ShowByCountry = 0;
    private int m_ShowByANS = 0;

    DataTable dt;

  
    private void GetQuery()
    {
      
        string StartDate = txtDate.Text;
        string EndtDate = txtDate1.Text;

       
        string groupInterval = getSelectedRadioButtonText();



        string constructedSQL = new SqlHelperIntlInIgw
                        (StartDate,
                         EndtDate,
                         groupInterval,
                         new List<string>()
                            {
                                CheckBoxPartner.Checked==true?"tup_inpartnerid":string.Empty,
                                CheckBoxShowByAns.Checked==true?"tup_destinationid":string.Empty,
                                CheckBoxShowByIgw.Checked==true?"tup_outpartnerid":string.Empty,
                                
                            },
                         new List<string>()
                            {
                                DropDownListPartner.SelectedIndex>0?" tup_inpartnerid="+DropDownListPartner.SelectedValue:string.Empty,
                                DropDownListAns.SelectedIndex>0?" tup_destinationId="+DropDownListAns.SelectedValue:string.Empty,
                                DropDownListIgw.SelectedIndex>0?" tup_outpartnerid="+DropDownListIgw.SelectedValue:string.Empty
                            }).getSQLString();

        File.WriteAllText("c:" + Path.DirectorySeparatorChar + "temp" + Path.DirectorySeparatorChar + "testQuery.txt", constructedSQL);
    }
    public string getSelectedRadioButtonText()
    {
        string interval = "";
        if (RadioButtonHalfHourly.Checked)
            return interval = "" + RadioButtonHalfHourly.Text;
        else if (RadioButtonHourly.Checked)
            return interval = "" + RadioButtonHourly.Text;
        else if (RadioButtonDaily.Checked)
            return interval = "" + RadioButtonDaily.Text;
        else if (RadioButtonWeekly.Checked)
            return interval = "" + RadioButtonWeekly.Text;
        else if (RadioButtonMonthly.Checked)
            return interval = "" + RadioButtonMonthly.Text;
        else if (RadioButtonYearly.Checked)
            return interval = "" + RadioButtonYearly.Text;
        else
            return "";
    }



    protected void submit_Click(object sender, EventArgs e)
    {
        GetQuery();

        if (CheckBoxShowByAns.Checked == true)
        {
            GridView1.Columns[3].Visible = true;
            //load ANS KPI
            Dictionary<string, partner> dicKpiAns = new Dictionary<string, partner>();
            using (PartnerEntities context = new PartnerEntities())
            {
                foreach (partner ThisPartner in context.partners.Where(c => c.PartnerType == 1).ToList())
                {
                    dicKpiAns.Add(ThisPartner.PartnerName, ThisPartner);
                }
                ViewState["dicKpiAns"] = dicKpiAns;
            }
        }
        else GridView1.Columns[3].Visible = false;

        if (CheckBoxShowByIgw.Checked == true)
        {
            GridView1.Columns[2].Visible = true;
        }
        else GridView1.Columns[2].Visible = false;

        if (CheckBoxPartner.Checked == true)
        {
            GridView1.Columns[1].Visible = true;
        }
        else GridView1.Columns[1].Visible = false;
        if (CheckBoxShowCost.Checked == true)
        {
            //GridView1.Columns[9].Visible = true;
            GridView1.Columns[10].Visible = true;
            GridView1.Columns[11].Visible = true;
            GridView1.Columns[12].Visible = true;
            GridView1.Columns[13].Visible = false;
            GridView1.Columns[14].Visible = true;
        }
        else
        {
            //GridView1.Columns[9].Visible = false;
            GridView1.Columns[10].Visible = false;
            GridView1.Columns[11].Visible = false;
            GridView1.Columns[12].Visible = false;
            GridView1.Columns[13].Visible = false;
            GridView1.Columns[14].Visible = false;
        }
        if (CheckBoxShowPerformance.Checked == true)
        {
            GridView1.Columns[15].Visible = true;
            GridView1.Columns[16].Visible = true;
            GridView1.Columns[17].Visible = true;
            GridView1.Columns[18].Visible = true;
            //GridView1.Columns[19].Visible = true;
            GridView1.Columns[20].Visible = true;

        }
        else
        {
            GridView1.Columns[15].Visible = false;
            GridView1.Columns[16].Visible = false;
            GridView1.Columns[17].Visible = false;
            GridView1.Columns[18].Visible = false;
            //GridView1.Columns[19].Visible = false;
            GridView1.Columns[20].Visible = false;

        }
        //make profit invisible, it's useless
        GridView1.Columns[15].Visible = false;
        //GridView1.Columns[9].Visible = true;//carrier's duration

        using (MySqlConnection connection = new MySqlConnection())
        {
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["reader"].ConnectionString;

            connection.Open();

            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = connection;

            //IF GROUP BY INTERNATIONAL CARRIER=FALSE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            if (CheckBoxPartner.Checked == false)
            {
                //if don't group by ANS
                if (CheckBoxShowByAns.Checked == false)
                {
                    //if don't group by IGW : NoAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntNoAnsNoIgw (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);

                    }
                    //if don't group by ANS, group by IGW ALL : NoAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntNoAnsGroupIGWAll (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                    }
                    //if don't group by ANS, group by IGW One : NoAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntNoAnsGroupIGWOne (@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if don't group by ans

                //if group by ANS ALL
                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                {
                    //if don't group by IGW : AllAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntAllAnsNoIgw (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);

                    }
                    //if group by ALL ANS, IGW ALL : IncIntAllAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntAllAnsGroupIGWAll (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                    }
                    //if group by ANS ALL,IGW One : IncIntAllAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntAllAnsGroupIGWOne (@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if group by ans ALL

                //if group by ANS One
                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                {
                    //if don't group by IGW : OneAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntOneAnsNoIGW (@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));

                    }
                    //if group by One ANS, IGW ALL : IncIntAllAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntOneAnsGroupIGWAll (@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                    }
                    //if group by ANS One,IGW One : IncIntOneAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntOneAnsGroupIGWOne (@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if group by ans One


            }//IF GROUP BY INTERNATIONAL CARRIER=FALSE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

            //IF GROUP BY INTERNATIONAL CARRIER ALL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            if ((CheckBoxPartner.Checked == true) && DropDownListPartner.SelectedValue == "-1")
            {
                //if don't group by ANS
                if (CheckBoxShowByAns.Checked == false)
                {
                    //if don't group by IGW : NoAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllNoAnsNoIgw (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);

                    }
                    //if don't group by ANS, group by IGW ALL : NoAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllNoAnsGroupIGWAll (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                    }
                    //if don't group by ANS, group by IGW One : NoAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllNoAnsGroupIGWOne (@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if don't group by ans

                //if group by ANS ALL
                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                {
                    //if don't group by IGW : AllAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllAllAnsNoIgw (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);

                    }
                    //if group by ALL ANS, IGW ALL : IncIntPartnerAllAllAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllAllAnsGroupIGWAll (@p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                    }
                    //if group by ANS ALL,IGW One : IncIntPartnerAllAllAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllAllAnsGroupIGWOne (@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if group by ans ALL

                //if group by ANS One
                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                {
                    //if don't group by IGW : OneAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllOneAnsNoIGW (@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));

                    }
                    //if group by One ANS, IGW ALL : IncIntPartnerAllAllAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllOneAnsGroupIGWAll (@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                    }
                    //if group by ANS One,IGW One : IncIntPartnerAllOneAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerAllOneAnsGroupIGWOne (@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if group by ans One


            }//IF GROUP BY INTERNATIONAL CARRIER ALL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

            //IF GROUP BY INTERNATIONAL CARRIER One^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            if ((CheckBoxPartner.Checked == true) && DropDownListPartner.SelectedValue != "-1")
            {
                //if don't group by ANS
                if (CheckBoxShowByAns.Checked == false)
                {
                    //if don't group by IGW : NoAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneNoAnsNoIgw (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);

                    }
                    //if don't group by ANS, group by IGW ALL : NoAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneNoAnsGroupIGWAll (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                    }
                    //if don't group by ANS, group by IGW One : NoAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneNoAnsGroupIGWOne (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if don't group by ans

                //if group by ANS ALL
                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                {
                    //if don't group by IGW : AllAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneAllAnsNoIgw (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);

                    }
                    //if group by ALL ANS, IGW ALL : IncIntPartnerOneAllAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneAllAnsGroupIGWAll (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                    }
                    //if group by ANS ALL,IGW One : IncIntPartnerOneAllAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneAllAnsGroupIGWOne (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if group by ans ALL

                //if group by ANS One
                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                {
                    //if don't group by IGW : OneAnsNoIgw
                    if (CheckBoxShowByIgw.Checked == false)
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneOneAnsNoIGW (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));

                    }
                    //if group by One ANS, IGW ALL : IncIntPartnerOneAllAnsGroupIGWAll
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneOneAnsGroupIGWAll (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                    }
                    //if group by ANS One,IGW One : IncIntPartnerOneOneAnsGroupIGWOne
                    else if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                    {

                        cmd.CommandText = "CALL IncIntPartnerOneOneAnsGroupIGWOne (@p_IntlPartner, @p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                        cmd.Parameters.AddWithValue("p_IntlPartner", DropDownListPartner.SelectedValue);

                        cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                        cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                        cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                        cmd.Parameters.AddWithValue("p_IgwId", Int32.Parse(DropDownListIgw.SelectedValue));
                    }

                } //if group by ans One


            }//IF GROUP BY INTERNATIONAL CARRIER One^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


            //Common Code**************#########################################
            Label1.Text = "";
            //this piece of code is important, reqport queries don't have date column when not summarized by day/hour etc.
            //need to hide gridview column[0] at times then
            if (RadioButtonHalfHourly.Checked == false)
            {

                GridView1.Columns[0].Visible = false;
            }
            else
            {
                GridView1.Columns[0].Visible = true;

            }


            //common code
            if (RadioButtonHalfHourly.Checked == true)
            {
                string SummaryInterval = "";
                if (RadioButtonHalfHourly.Checked == true)
                {
                    SummaryInterval = "Halfhourly";
                    GridView1.Columns[0].HeaderText = "Half Hour";
                }
                else if (RadioButtonHourly.Checked == true)
                {
                    SummaryInterval = "Hourly";
                    GridView1.Columns[0].HeaderText = "Hour";
                }
                else if (RadioButtonDaily.Checked == true)
                {
                    SummaryInterval = "Daily";
                    GridView1.Columns[0].HeaderText = "Date";
                }
                else if (RadioButtonWeekly.Checked == true)
                {
                    SummaryInterval = "Weekly";
                    GridView1.Columns[0].HeaderText = "Week";
                }
                else if (RadioButtonMonthly.Checked == true)
                {
                    SummaryInterval = "Monthly";
                    GridView1.Columns[0].HeaderText = "Month";
                }
                else if (RadioButtonYearly.Checked == true)
                {
                    SummaryInterval = "Yearly";
                    GridView1.Columns[0].HeaderText = "Year";
                }

                cmd.CommandText = cmd.CommandText.Replace("CALL ", "CALL " + SummaryInterval + "Summary");

            }

            //source for report... cdr or summary data
            switch (DropDownListReportSource.SelectedValue)
            {
                case "1"://CDR
                    break;
                case "2"://Summary Data
                    cmd.CommandText = cmd.CommandText.Replace("CALL ", "CALL SD");
                    break;
                case "3"://Cdr Error
                    cmd.CommandText = cmd.CommandText.Replace("CALL ", "CALL Err");
                    break;
            }

            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet dataset = new DataSet();
            da.Fill(dataset);


            GridView1.DataSource = dataset;
            bool hasRows = dataset.Tables.Cast<DataTable>()
                               .Any(table => table.Rows.Count != 0);
            if (hasRows == true)
            {
                GridView1.ShowFooter = true;//set it here before setting footer text, setting this to true clears already set footer text
                Label1.Text = "";
                Button1.Visible = true; //show export
                //Summary calculation for grid view*************************
                TrafficReportDatasetBased tr = new TrafficReportDatasetBased(dataset);
                tr.ds = dataset;
                List<NoOfCallsVsPDD> callVsPdd = new List<NoOfCallsVsPDD>();
                foreach (DataRow dr in tr.ds.Tables[0].Rows)
                {
                    tr.callStat.TotalCalls += tr.ForceConvertToLong(dr["CallsCount"]);
                    tr.callStat.ConnectedCalls += tr.ForceConvertToLong(dr["ConnectedCount"]);
                    tr.callStat.ConnectedCallsbyCauseCodes += tr.ForceConvertToLong(dr["ConnectByCC"]);
                    tr.callStat.SuccessfullCalls += tr.ForceConvertToLong(dr["Number Of Calls (International Incoming)"]);
                    tr.callStat.TotalActualDuration += tr.ForceConvertToDouble(dr["Paid Minutes (International Incoming)"]);
                    tr.callStat.TotalRoundedDuration += tr.ForceConvertToDouble(dr["RoundedDuration"]);
                    tr.callStat.TotalDuration1 += tr.ForceConvertToDouble(dr["Duration1"]);
                    NoOfCallsVsPDD cpdd = new NoOfCallsVsPDD(tr.ForceConvertToLong(dr["Number Of Calls (International Incoming)"]), tr.ForceConvertToDouble(dr["PDD"]));
                    callVsPdd.Add(cpdd);
                }
                tr.callStat.TotalActualDuration = Math.Round(tr.callStat.TotalActualDuration, 2);
                tr.callStat.TotalDuration1 = Math.Round(tr.callStat.TotalDuration1, 2);
                tr.callStat.TotalDuration2 = Math.Round(tr.callStat.TotalDuration2, 2);
                tr.callStat.TotalDuration3 = Math.Round(tr.callStat.TotalDuration3, 2);
                tr.callStat.TotalDuration4 = Math.Round(tr.callStat.TotalDuration4, 2);
                tr.callStat.TotalRoundedDuration = Math.Round(tr.callStat.TotalRoundedDuration, 2);
                tr.callStat.CalculateASR(2);
                tr.callStat.CalculateACD(2);
                tr.callStat.CalculateAveragePDD(callVsPdd, 2);
                tr.callStat.CalculateCCR(2);
                tr.callStat.CalculateCCRbyCauseCode(2);
                //SUMMARY CALCULATION FOR GRIDVIEW COMPLETE


                //display summary information in the footer
                Dictionary<string, dynamic> fieldSummaries = new Dictionary<string, dynamic>();//key=colname,val=colindex in grid
                //all keys have to be lowercase, because db fields are lower case at times
                fieldSummaries.Add("callscount", tr.callStat.TotalCalls);
                fieldSummaries.Add("connectedcount", tr.callStat.ConnectedCalls);
                fieldSummaries.Add("connectbycc", tr.callStat.ConnectedCallsbyCauseCodes);
                fieldSummaries.Add("number of calls (international incoming)", tr.callStat.SuccessfullCalls);
                fieldSummaries.Add("paid minutes (international incoming)", tr.callStat.TotalActualDuration);
                fieldSummaries.Add("roundedduration", tr.callStat.TotalRoundedDuration);
                fieldSummaries.Add("duration1", tr.callStat.TotalDuration1);
                fieldSummaries.Add("asr", tr.callStat.ASR);
                fieldSummaries.Add("acd", tr.callStat.ACD);
                fieldSummaries.Add("pdd", tr.callStat.PDD);
                fieldSummaries.Add("ccr", tr.callStat.CCR);
                fieldSummaries.Add("ccrbycc", tr.callStat.CCRbyCauseCode);
                tr.fieldSummaries = fieldSummaries;

                Session["IntlIn"] = tr;//save to session

                //populate footer
                //clear first
                bool CaptionSetForTotal = false;
                for (int c = 0; c < GridView1.Columns.Count; c++)
                {
                    GridView1.Columns[c].FooterText = "";
                }
                for (int c = 0; c < GridView1.Columns.Count; c++)
                {
                    if (CaptionSetForTotal == false && GridView1.Columns[c].Visible == true)
                    {
                        GridView1.Columns[c].FooterText = "Total: ";//first visible column
                        CaptionSetForTotal = true;
                    }
                    string key = GridView1.Columns[c].SortExpression.ToLower();
                    if (key == "") continue;
                    if (tr.fieldSummaries.ContainsKey(key))
                    {
                        GridView1.Columns[c].FooterText += (tr.GetDataColumnSummary(key)).ToString();//+ required to cocat "Total:"
                    }
                }
                GridView1.DataBind();//call it here after setting footer, footer text doesn't show sometime otherwise, may be a bug
                GridView1.ShowFooter = true;//don't set it now, set before footer text setting, weird! it clears the footer text
                //hide filters...
                Page.ClientScript.RegisterStartupScript(GetType(), "MyKey", "HideParamBorderDivSubmit();", true);
                hidValueSubmitClickFlag.Value = "false";

            }//if has rows

            else
            {
                GridView1.DataBind();
                Label1.Text = "No Data!";
                Button1.Visible = false; //hide export
            }

        }//using mysql connection




    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Session["IntlIn"] != null) //THIS MUST BE CHANGED IN EACH PAGE
        {
            TrafficReportDatasetBased tr = (TrafficReportDatasetBased)Session["IntlIn"];
            DataSetWithGridView dsG = new DataSetWithGridView(tr, GridView1);//invisible columns are removed in constructor
            CreateExcelFileAspNet.CreateExcelDocumentAsStreamEpPlusPackageLastRowSummary(tr.ds, "IntlIncoming_" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    + ".xlsx", Response);
        }
    }





    protected void CheckBoxShowByPartner_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxPartner.Checked == true)
        {
            DropDownListPartner.Enabled = true;
        }
        else DropDownListPartner.Enabled = false;
    }


    protected void CheckBoxShowByAns_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxShowByAns.Checked == true)
        {
            DropDownListAns.Enabled = true;
        }
        else DropDownListAns.Enabled = false;
    }
    protected void CheckBoxShowByIgw_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxShowByIgw.Checked == true)
        {
            DropDownListIgw.Enabled = true;
        }
        else DropDownListIgw.Enabled = false;

    }



    protected void CheckBoxRealTimeUpdate_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxRealTimeUpdate.Checked)
        {
            //Disable DailySummary,Destination, Dates& Months

            //  CheckBoxDailySummary.Checked = false;
            //  CheckBoxDailySummary.Enabled = false;

            // CheckBoxShowByDestination.Checked = false;
            //CheckBoxShowByDestination.Enabled = false;

            TextBoxYear.Enabled = false;
            DropDownListMonth.Enabled = false;
            txtDate.Enabled = false;

            TextBoxYear1.Enabled = false;
            DropDownListMonth1.Enabled = false;
            txtDate1.Enabled = false;

            //Enable Timers,Duration,country
            //CheckBoxShowByCountry.Checked = true;
            TextBoxDuration.Enabled = true;
            //TextBoxDuration.Text = "30";
            //timerflag = true;



            //dateInitialize
        }
        else
        {
            //Enable DailySummary,Destination, Dates& Months

            //CheckBoxDailySummary.Checked = true;
            // CheckBoxDailySummary.Enabled = true;

            // CheckBoxShowByDestination.Checked = true;
            // CheckBoxShowByDestination.Enabled = true;

            TextBoxYear.Enabled = true;
            DropDownListMonth.Enabled = true;
            txtDate.Enabled = true;

            TextBoxYear1.Enabled = true;
            DropDownListMonth1.Enabled = true;
            txtDate1.Enabled = true;

            //Disable Timers,Duration,
            //CheckBoxShowByCountry.Checked = false;
            TextBoxDuration.Enabled = false;
            //TextBoxDuration.Text = "30";
            //timerflag = false;
        }
        //CheckBoxShowByCountry_CheckedChanged(sender, e);
        dateInitialize();
    }

    public void dateInitialize()
    {
        if (CheckBoxRealTimeUpdate.Checked)
        {
            long a;
            if (!long.TryParse(TextBoxDuration.Text, out a))
            {
                // If Not Integer Clear Textbox text or you can also Undo() Last Operation :)

                TextBoxDuration.Text = "30";
                a = 30;
            }

            DateTime endtime = DateTime.Now;
            DateTime starttime = endtime.AddMinutes(a * (-1));
            txtDate1.Text = endtime.ToString("dd/MM/yyyy HH:mm:ss");
            txtDate.Text = starttime.ToString("dd/MM/yyyy HH:mm:ss");

            //return true;
        }
        //else
        //{
        //    txtDate.Text = FirstDayOfMonthFromDateTime(System.DateTime.Now).ToString("dd/MM/yyyy");
        //    txtDate1.Text = LastDayOfMonthFromDateTime(System.DateTime.Now).ToString("dd/MM/yyyy");
        //}
    }

    protected void TextBoxDuration_TextChanged(object sender, EventArgs e)
    {
        long a;
        if (!long.TryParse(TextBoxDuration.Text, out a))
        {
            // If Not Integer Clear Textbox text or you can also Undo() Last Operation :)

            TextBoxDuration.Text = "30";
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
        if (CheckBoxRealTimeUpdate.Checked)
        {
            submit_Click(sender, e);
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            return;
        }

        if (CheckBoxShowByAns.Checked == true)
        {
            Dictionary<string, partner> dicKpiAns = null;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (ViewState["dicKpiAns"] != null)
                {
                    dicKpiAns = (Dictionary<string, partner>)ViewState["dicKpiAns"];
                }
                else
                {
                    return;
                }
                //Label lblCountry = (Label)e.Row.FindControl("Label3");
                string ThisANSName = DataBinder.Eval(e.Row.DataItem, "ANS").ToString();
                Single ThisASR = 0;
                Single ThisACD = 0;
                Single ThisCCR = 0;
                Single ThisPDD = 0;
                Single ThisCCRbyCC = 0;
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "ASR").ToString(), out ThisASR);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "ACD").ToString(), out ThisACD);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "CCR").ToString(), out ThisCCR);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "PDD").ToString(), out ThisPDD);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "CCRByCC").ToString(), out ThisCCRbyCC);
                partner ThisPartner = null;
                dicKpiAns.TryGetValue(ThisANSName, out ThisPartner);
                if (ThisPartner != null)
                {
                    Color RedColor = ColorTranslator.FromHtml("#FF0000");
                    //ASR
                    Single RefAsr = 0;
                    if (Convert.ToSingle(ThisPartner.refasr) > 0)
                    {
                        RefAsr = Convert.ToSingle(ThisPartner.refasr);
                    }
                    if ((ThisASR < RefAsr) || (ThisASR == 0))
                    {
                        e.Row.Cells[16].ForeColor = Color.White;
                        e.Row.Cells[16].BackColor = RedColor;
                        e.Row.Cells[16].Font.Bold = true;
                    }

                    //fas detection
                    double TempDbl = 0;
                    double RefAsrFas = RefAsr + RefAsr * .5;//fas threshold= 30% of ref asr by default
                    double.TryParse(ThisPartner.refasrfas.ToString(), out TempDbl);
                    if (TempDbl > 0) RefAsrFas = TempDbl;

                    if (ThisASR > RefAsrFas && RefAsrFas > 0)
                    {
                        e.Row.Cells[16].ForeColor = Color.White;
                        e.Row.Cells[16].BackColor = Color.Blue;
                        e.Row.Cells[16].Font.Bold = true;
                    }

                    //ACD
                    Single RefAcd = 0;
                    if (Convert.ToSingle(ThisPartner.refacd) > 0)
                    {
                        RefAcd = Convert.ToSingle(ThisPartner.refacd);
                    }
                    if (ThisACD < RefAcd)
                    {
                        //e.Row.Cells[16].ForeColor = RedColor;
                        e.Row.Cells[17].ForeColor = Color.White;
                        e.Row.Cells[17].BackColor = RedColor;
                        e.Row.Cells[17].Font.Bold = true;
                    }

                    //PDD
                    Single RefPdd = 0;
                    if (Convert.ToSingle(ThisPartner.refpdd) > 0)
                    {
                        RefPdd = Convert.ToSingle(ThisPartner.refpdd);
                    }
                    if (ThisPDD > RefPdd)
                    {
                        //e.Row.Cells[17].ForeColor = RedColor;
                        e.Row.Cells[18].ForeColor = Color.White;
                        e.Row.Cells[18].BackColor = RedColor;
                        e.Row.Cells[18].Font.Bold = true;
                    }

                    //CCR
                    Single RefCcr = 0;
                    if (Convert.ToSingle(ThisPartner.refccr) > 0)
                    {
                        RefCcr = Convert.ToSingle(ThisPartner.refccr);
                    }
                    if (ThisCCR < RefCcr)
                    {
                        //e.Row.Cells[18].ForeColor = RedColor;
                        e.Row.Cells[19].ForeColor = Color.White;
                        e.Row.Cells[19].BackColor = RedColor;
                        e.Row.Cells[19].Font.Bold = true;
                    }

                    //CCRByCauseCode
                    Single RefCcrCC = 0;
                    if (Convert.ToSingle(ThisPartner.refccrbycc) > 0)
                    {
                        RefCcrCC = Convert.ToSingle(ThisPartner.refccrbycc);
                    }
                    if (ThisCCRbyCC < RefCcrCC)
                    {
                        //e.Row.Cells[20].ForeColor = RedColor;
                        e.Row.Cells[21].ForeColor = Color.White;
                        e.Row.Cells[21].BackColor = RedColor;
                        e.Row.Cells[21].Font.Bold = true;
                    }
                }
            }
        }//if checkbox ans

        //0 ASR highlighting
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            double ASR = 1;
            double.TryParse(e.Row.Cells[16].Text, out ASR);
            Color RedColor2 = ColorTranslator.FromHtml("#FF0000");
            if (ASR <= 0)
            {
                e.Row.Cells[16].ForeColor = Color.White;
                e.Row.Cells[16].BackColor = RedColor2;
                e.Row.Cells[16].Font.Bold = true;
            }
        }

    }
}
