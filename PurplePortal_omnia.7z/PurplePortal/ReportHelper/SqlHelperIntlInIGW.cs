﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace PortalApp
{
    public class SqlHelperIntlInIgw : AbstractSqlHelper
    {
        public SqlHelperIntlInIgw(string startDate, string endDate, string groupInterval,
                                    List<string> groupExpressions, List<string> whereExpressions)
        {
            StartDate = startDate;
            EndDate = endDate;
            this.groupInterval = groupInterval;
            this.groupExpressions = groupExpressions;
            this.whereExpressions = whereExpressions;
        }
    }
}