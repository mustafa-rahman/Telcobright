using MediationModel;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ExportToExcel;
using reports;
using PortalApp;
using System.IO;

public partial class _DefaultRptIntlOut : System.Web.UI.Page
{
    DataTable dt; bool timerflag = false;

    private void GetQuery()
    {

        string StartDate = txtDate.Text;
        string EndtDate = txtDate1.Text;


        string groupInterval = getSelectedRadioButtonText();



        string constructedSQL = new SqlHelperIntlInIgw
                        (StartDate,
                         EndtDate,
                         groupInterval,
                         new List<string>()
                            {
                                CheckBoxShowByCountry.Checked==true?"tup_countryorareacode":string.Empty,
                                CheckBoxIntlPartner.Checked==true?"tup_outpartnerid":string.Empty,
                                CheckBoxShowByAns.Checked==true?"tup_sourceID":string.Empty,
                                CheckBoxShowByIgw.Checked==true?"tup_intpartnerid":string.Empty,

                            },
                         new List<string>()
                            {
                                DropDownListCountry.SelectedIndex>0?" tup_inpartnerid="+DropDownListCountry.SelectedValue:string.Empty,
                                DropDownPrefix.SelectedIndex>0?" tup_inpartnerid="+DropDownPrefix.SelectedValue:string.Empty,
                                DropDownListIntlCarier.SelectedIndex>0?" tup_inpartnerid="+DropDownListIntlCarier.SelectedValue:string.Empty,
                                DropDownListAns.SelectedIndex>0?" tup_destinationId="+DropDownListAns.SelectedValue:string.Empty,
                                DropDownListIgw.SelectedIndex>0?" tup_outpartnerid="+DropDownListIgw.SelectedValue:string.Empty
                            }).getSQLString();

        File.WriteAllText("c:" + Path.DirectorySeparatorChar + "temp" + Path.DirectorySeparatorChar + "testQuery.txt", constructedSQL);
    }


    public string getSelectedRadioButtonText()
    {
        string interval = "";
        if (RadioButtonHalfHourly.Checked)
            return interval = "" + RadioButtonHalfHourly.Text;
        else if (RadioButtonHourly.Checked)
            return interval = "" + RadioButtonHourly.Text;
        else if (RadioButtonDaily.Checked)
            return interval = "" + RadioButtonDaily.Text;
        else if (RadioButtonWeekly.Checked)
            return interval = "" + RadioButtonWeekly.Text;
        else if (RadioButtonMonthly.Checked)
            return interval = "" + RadioButtonMonthly.Text;
        else if (RadioButtonYearly.Checked)
            return interval = "" + RadioButtonYearly.Text;
        else
            return "";
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        GetQuery();
        TelcobrightEntityConfig tbc = (TelcobrightEntityConfig)Application["telcobrightConfig"];
        PageUtil.ApplyPageSettings(this,false, tbc);
        //load Country KPI

        Dictionary<string, countrycode> dicKpiCountry = new Dictionary<string, countrycode>();
        using (PartnerEntities context = new PartnerEntities())
        {
            foreach (countrycode C in context.countrycodes.ToList())
            {
                dicKpiCountry.Add(C.Code, C);
            }
            Session["dicKpiCountry"] = dicKpiCountry;
        }

        //load Destination KPI
        Dictionary<string, xyzprefix> dicKpiDest = new Dictionary<string, xyzprefix>();
        using (PartnerEntities context = new PartnerEntities())
        {
            foreach (xyzprefix C in context.xyzprefixes.ToList())
            {
                dicKpiDest.Add(C.Prefix, C);
            }
            Session["dicKpiDest"] = dicKpiDest;
        }

        //common code for report pages
        //view state of ParamBorder div
        string TempText = hidValueFilter.Value;
        bool LastVisible = hidValueFilter.Value == "invisible" ? false : true;
        if (hidValueSubmitClickFlag.Value == "false")
        {
            if (LastVisible)
            {
                //show filters...
                Page.ClientScript.RegisterStartupScript(GetType(), "MyKey", "ShowParamBorderDiv();", true);
            }
            else
            {
                //hide filters...
                Page.ClientScript.RegisterStartupScript(GetType(), "MyKey", "HideParamBorderDiv();", true);
            }
        }
        //set this month's start and End Date [Time] in the date picker controls...
        if (!IsPostBack)
        {
            //set summary as report source default
            DropDownListReportSource.SelectedIndex = 1;
            //get latest usd rate
            Single UsdExchangeRate = 0;
            var connectionString = ConfigurationManager.ConnectionStrings["reader"].ConnectionString;
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string Sql;
                Sql = " select RateAmount from usdexchangerateagainstbdt where field1=2 order by Field2 desc limit 0,1;";
                using (MySqlCommand command = new MySqlCommand(Sql, connection))
                {

                    command.CommandType = CommandType.Text;

                    MySqlDataReader myReader;
                    myReader = command.ExecuteReader();
                    try
                    {
                        while (myReader.Read())
                        {

                            if (Single.Parse(myReader["RateAmount"].ToString()) > 0)
                            {

                                UsdExchangeRate = Single.Parse(myReader["RateAmount"].ToString());

                            }

                        }
                    }
                    catch (Exception e1)
                    {
                        //Console.WriteLine("{0} Exception caught.", e);
                        UsdExchangeRate = 0;

                    }

                    finally
                    {

                        myReader.Close();
                        connection.Close();
                    }

                    TextBoxUsdRate.Text = UsdExchangeRate.ToString();

                }//using mysql command
            }//using mysql connection	

            TextBoxYear.Text = System.DateTime.Now.ToString("yyyy");
            TextBoxYear1.Text = System.DateTime.Now.ToString("yyyy");
            DropDownListMonth.SelectedIndex = int.Parse(System.DateTime.Now.ToString("MM")) - 1;
            DropDownListMonth1.SelectedIndex = int.Parse(System.DateTime.Now.ToString("MM")) - 1;
            //txtDate.Text = FirstDayOfMonthFromDateTime(System.DateTime.Now).ToString("dd/MM/yyyy");
            //txtDate1.Text = LastDayOfMonthFromDateTime(System.DateTime.Now).ToString("dd/MM/yyyy");
            txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtDate1.Text = DateTime.Now.ToString("dd/MM/yyyy");


            //set controls if page is called for a template
            TreeView MasterTree = (TreeView)Master.FindControl("TreeView1");
            NameValueCollection n = Request.QueryString;
            CommonCode CommonCodes = new CommonCode();
            if (n.HasKeys())
            {
                string TemplateName = "";
                var items = n.AllKeys.SelectMany(n.GetValues, (k, v) => new { key = k, value = v });
                foreach (var ThisParam in items)
                {
                    if (ThisParam.key == "templ")
                    {
                        TemplateName = ThisParam.value;
                        break;
                    }
                }
                if (TemplateName != "")
                {
                    //set controls here ...
                    string RetVal = CommonCodes.SetTemplateControls(this, TemplateName);
                    if (RetVal != "success")
                    {
                        string script = "alert('Error occured while loading template: " + TemplateName
                            + "! " + Environment.NewLine + RetVal + "');";
                        ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                        return;
                    }
                }
                //Load Report Templates in TreeView dynically from database.
                CommonCode CommonCode = new CommonCode();
                CommonCode.LoadReportTemplatesTree(ref MasterTree);
            }
            //Retrieve Path from TreeView for displaying in the master page caption label
            string LocalPath = Request.Url.LocalPath;
            int Pos2ndSlash = LocalPath.Substring(1, LocalPath.Length - 1).IndexOf("/");
            string Root_Folder = LocalPath.Substring(1, Pos2ndSlash);
            int EndOfRootFolder = Request.Url.AbsoluteUri.IndexOf(Root_Folder);
            string UrlWithQueryString = ("~" +"/"+Root_Folder + Request.Url.AbsoluteUri.Substring((EndOfRootFolder + Root_Folder.Length), Request.Url.AbsoluteUri.Length - (EndOfRootFolder + Root_Folder.Length))).Replace("%20", " ");
            TreeNodeCollection cNodes = MasterTree.Nodes;
            TreeNode MatchedNode = null;
            foreach (TreeNode N in cNodes)//for each nodes at root level, loop through children
            {
                MatchedNode = CommonCodes.RetrieveNodes(N, UrlWithQueryString);
                if (MatchedNode != null)
                {
                    break;
                }
            }
            //set screentile/caption in the master page...
            Label lblScreenTitle = (Label)Master.FindControl("lblScreenTitle");
            lblScreenTitle.Text = "";
            if (MatchedNode != null)
            {
                lblScreenTitle.Text = MatchedNode.ValuePath;
            }
            else
            {
                lblScreenTitle.Text = "";
            }
            if (lblScreenTitle.Text == "")
            {
                lblScreenTitle.Text = "Reports/Intl. Outgoing/Traffic";
            }

            //End of Site Map Part *******************************************************************

        }

        hidValueSubmitClickFlag.Value = "false";

        //load prefix dropdown combo
        string PrefixFilter = "-1";
        if (DropDownListCountry.SelectedValue != "")//avoid executing during initial page load when selected value is not set
        {
            PrefixFilter = DropDownListCountry.SelectedValue;
        }

        if (!IsPostBack)
        {
            using (MySqlConnection Con = new MySqlConnection(ConfigurationManager.ConnectionStrings["reader"].ConnectionString))
            {
                Con.Open();
                using (MySqlCommand cmd = new MySqlCommand("", Con))
                {
                    cmd.CommandText = "CALL OutgoingPrefix(@p_CountryCode)";
                    cmd.Parameters.AddWithValue("p_CountryCode", PrefixFilter);

                    MySqlDataReader dr = cmd.ExecuteReader();
                    DropDownPrefix.Items.Clear();
                    while (dr.Read())
                    {
                        DropDownPrefix.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
                    }
                }
            }
        }

    }



    public DateTime FirstDayOfMonthFromDateTime(DateTime dateTime)
    {
        return new DateTime(dateTime.Year, dateTime.Month, 1);
    }

    public DateTime LastDayOfMonthFromDateTime(DateTime dateTime)
    {
        DateTime firstDayOfTheMonth = new DateTime(dateTime.Year, dateTime.Month, 1);
        return firstDayOfTheMonth.AddMonths(1).AddDays(-1);
    }

    protected void DropDownListMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        //select 15th of month to find out first and last day of a month as it exists in all months.
        DateTime AnyDayOfMonth = new DateTime(int.Parse(TextBoxYear.Text), int.Parse(DropDownListMonth.SelectedValue), 15);
        txtDate.Text = FirstDayOfMonthFromDateTime(AnyDayOfMonth).ToString("dd/MM/yyyy");
    }
    protected void DropDownListMonth1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //select 15th of month to find out first and last day of a month as it exists in all months.
        DateTime AnyDayOfMonth = new DateTime(int.Parse(TextBoxYear1.Text), int.Parse(DropDownListMonth1.SelectedValue), 15);
        txtDate1.Text = LastDayOfMonthFromDateTime(AnyDayOfMonth).ToString("dd/MM/yyyy");
    }








    protected void ButtonTemplate_Click(object sender, EventArgs e)
    {
        //exit if cancel clicked in javascript...
        if (hidValueTemplate.Value == null || hidValueTemplate.Value == "")
        {
            return;
        }

        //check for duplicate templatename and alert the client...
        string TemplateName = hidValueTemplate.Value;
        if (TemplateName == "")
        {
            string script = "alert('Templatename cannot be empty!');";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
            return;
        }
        else if (TemplateName.IndexOf('=') >= 0 || TemplateName.IndexOf(':') >= 0 ||
            TemplateName.IndexOf(',') >= 0 || TemplateName.IndexOf('?') >= 0)
        {
            string script = "alert('Templatename cannot contain characters =:,?');";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
            return;
        }
        using (PartnerEntities context = new PartnerEntities())
        {
            if (context.reporttemplates.Any(c => c.Templatename == TemplateName))
            {
                string script = "alert('Templatename: " + TemplateName + " exists, try a different name.');";
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                return;
            }
        }
        string LocalPath = Request.Url.LocalPath;
        int Pos2ndSlash = LocalPath.Substring(1, LocalPath.Length - 1).IndexOf("/");
        string Root_Folder = LocalPath.Substring(1, Pos2ndSlash);
        int EndOfRootFolder = Request.Url.AbsoluteUri.IndexOf(Root_Folder);
        string UrlWithQueryString = "~" + Request.Url.AbsoluteUri.Substring((EndOfRootFolder + Root_Folder.Length), Request.Url.AbsoluteUri.Length - (EndOfRootFolder + Root_Folder.Length));
        int PosQMark = UrlWithQueryString.IndexOf("?");
        string UrlWithoutQS = (PosQMark < 0 ? UrlWithQueryString : UrlWithQueryString.Substring(0, PosQMark)).Replace("~","~/reports");
        CommonCode CommonCode = new CommonCode();
        string RetVal = CommonCode.SaveTemplateControlsByPage(this, TemplateName, UrlWithoutQS);
        
        TreeView MasterTree = (TreeView)Page.Master.FindControl("Treeview1");
        CommonCode.LoadReportTemplatesTree(ref MasterTree);

        //Retrieve Path from TreeView for displaying in the master page caption label
        TreeNodeCollection cNodes = MasterTree.Nodes;
        TreeNode MatchedNode = null;
        foreach (TreeNode N in cNodes)//for each nodes at root level, loop through children
        {
            MatchedNode = CommonCode.RetrieveNodes(N, UrlWithoutQS + "?templ=" + TemplateName);
            if (MatchedNode != null)
            {
                break;
            }
        }
        //set screentile/caption in the master page...
        Label lblScreenTitle = (Label)Master.FindControl("lblScreenTitle");
        if (MatchedNode != null)
        {
            lblScreenTitle.Text = MatchedNode.ValuePath;
        }
        else
        {
            lblScreenTitle.Text = "";
        }

        if (RetVal == "success")
        {
            string ScrSuccess = "alert('Template created successfully');";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", ScrSuccess, true);
        }

    }
         
    protected void submit_Click(object sender, EventArgs e)
    {
        //view by country/prefix logic has been changed later, adding this new flag
        bool NotViewingByCountry=CheckBoxShowByDestination.Checked | (!CheckBoxShowByCountry.Checked);//not viewing by country if view by desination is checked

        //undo the effect of hiding some grid by the summary button first******************
        GridView1.Columns[0].Visible = true;
        GridView1.Columns[1].Visible = true;
        //GridView1.Columns[2].Visible = false;
        //GridView1.Columns[3].Visible = false;
        //GridView1.Columns[4].Visible = false;
        //*****************************

        if (CheckBoxShowByCountry.Checked == true)
        {
            GridView1.Columns[2].Visible = false;
        }
        else GridView1.Columns[2].Visible = true;

        if (CheckBoxShowByAns.Checked == true)
        {
            GridView1.Columns[3].Visible = true;
        }
        else GridView1.Columns[3].Visible = false;

        if (CheckBoxShowByIgw.Checked == true)
        {
            GridView1.Columns[4].Visible = true;
        }
        else GridView1.Columns[4].Visible = false;

        if (CheckBoxIntlPartner.Checked == true)
        {
            GridView1.Columns[5].Visible = true;
        }
        else GridView1.Columns[5].Visible = false;

        if (CheckBoxShowPerformance.Checked == true)
        {
            GridView1.Columns[13].Visible = true;
            GridView1.Columns[14].Visible = true;
            GridView1.Columns[15].Visible = true;
            //GridView1.Columns[16].Visible = true;
            GridView1.Columns[17].Visible = true;
            GridView1.Columns[18].Visible = true;
        }
        else
        {
            GridView1.Columns[13].Visible = false;
            GridView1.Columns[14].Visible = false;
            GridView1.Columns[15].Visible = false;
            //GridView1.Columns[16].Visible = false;
            GridView1.Columns[17].Visible = false;
            GridView1.Columns[18].Visible = false;
        }

        if (CheckBoxShowCost.Checked == true)
        {
            GridView1.Columns[19].Visible = true;
            GridView1.Columns[20].Visible = true;
            GridView1.Columns[21].Visible = true;
            GridView1.Columns[22].Visible = true;
            GridView1.Columns[23].Visible = true;
            GridView1.Columns[24].Visible = true;
            GridView1.Columns[25].Visible = true;

        }
        else
        {

            GridView1.Columns[19].Visible = false;
            GridView1.Columns[20].Visible = false;
            GridView1.Columns[21].Visible = false;
            GridView1.Columns[22].Visible = false;
            GridView1.Columns[23].Visible = false;
            GridView1.Columns[24].Visible = false;
            GridView1.Columns[25].Visible = false;
        }

        

        using (MySqlConnection connection = new MySqlConnection())
        {

            connection.ConnectionString = ConfigurationManager.ConnectionStrings["reader"].ConnectionString;

            connection.Open();

            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = connection;

            //All Possible Report Combinations are here:

            //^^^^^^^^^^^*********&&&&&&&&&&&&&&&& if checkbox view by destination is checked

            if (CheckBoxShowByDestination.Checked == true || CheckBoxShowByCountry.Checked == true)
            {

                GridView1.Columns[1].Visible = true;//country
                if (CheckBoxShowByDestination.Checked)
                    GridView1.Columns[2].Visible = true;//destination
                else
                    GridView1.Columns[2].Visible = false;


                //IF GROUP BY INTERNATIONAL PARTNER=FALSE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                if (CheckBoxIntlPartner.Checked == false)
                {
                    //By Country Only, GROUP BY COUNTRY=ALL
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:1

                                cmd.CommandText = "CALL OutIntCase1 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:2

                                cmd.CommandText = "CALL OutIntCase2 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:3

                                cmd.CommandText = "CALL OutIntCase3 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:4

                                cmd.CommandText = "CALL OutIntCase4 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:5

                                cmd.CommandText = "CALL OutIntCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                //cmd.CommandText = "CALL SummaryOutIntCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:6

                                cmd.CommandText = "CALL OutIntCase6 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:7

                                cmd.CommandText = "CALL OutIntCase7 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:8

                                cmd.CommandText = "CALL OutIntCase8 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:9

                                cmd.CommandText = "CALL OutIntCase9 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ALL

                    //*************************************************************************************
                    //By Country Only, GROUP BY COUNTRY=ONE
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:10

                                cmd.CommandText = "CALL OutIntCase10 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);

                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:11

                                cmd.CommandText = "CALL OutIntCase11 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:12

                                cmd.CommandText = "CALL OutIntCase12 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:13

                                cmd.CommandText = "CALL OutIntCase13 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:14

                                cmd.CommandText = "CALL OutIntCase14 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:15

                                cmd.CommandText = "CALL OutIntCase15 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:16

                                cmd.CommandText = "CALL OutIntCase16 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:17

                                cmd.CommandText = "CALL OutIntCase17 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:18

                                cmd.CommandText = "CALL OutIntCase18 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ONE

                    //********prefix

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutIntCase19 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutIntCase20 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutIntCase21 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutIntCase22 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutIntCase23 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutIntCase24 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutIntCase25 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutIntCase26 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutIntCase27 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutIntCase28 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutIntCase29 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutIntCase30 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutIntCase31 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutIntCase32 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutIntCase33 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutIntCase34 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutIntCase35 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutIntCase36 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }
                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************



                    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ONE***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutIntOneCountryCase19 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutIntOneCountryCase20 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutIntOneCountryCase21 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutIntOneCountryCase22 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutIntOneCountryCase23 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutIntOneCountryCase24 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutIntOneCountryCase25 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutIntOneCountryCase26 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutIntOneCountryCase27 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutIntOneCountryCase28 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutIntOneCountryCase29 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutIntOneCountryCase30 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutIntOneCountryCase31 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutIntOneCountryCase32 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutIntOneCountryCase33 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutIntOneCountryCase34 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutIntOneCountryCase35 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutIntOneCountryCase36 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }


                }//IF GROUP BY INTERNATIONAL PARTNER=FALSE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


                //IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER ALL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                if ((CheckBoxIntlPartner.Checked == true) && (DropDownListIntlCarier.SelectedValue == "-1"))
                {
                    //By Country Only, GROUP BY COUNTRY=ALL
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:1

                                cmd.CommandText = "CALL OutIntPartnerAllCase1 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:2

                                cmd.CommandText = "CALL OutIntPartnerAllCase2 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:3

                                cmd.CommandText = "CALL OutIntPartnerAllCase3 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:4

                                cmd.CommandText = "CALL OutIntPartnerAllCase4 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:5

                                cmd.CommandText = "CALL OutIntPartnerAllCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                //cmd.CommandText = "CALL SummaryOutIntPartnerAllCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:6

                                cmd.CommandText = "CALL OutIntPartnerAllCase6 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:7

                                cmd.CommandText = "CALL OutIntPartnerAllCase7 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:8

                                cmd.CommandText = "CALL OutIntPartnerAllCase8 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:9

                                cmd.CommandText = "CALL OutIntPartnerAllCase9 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ALL

                    //*************************************************************************************
                    //By Country Only, GROUP BY COUNTRY=ONE
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:10

                                cmd.CommandText = "CALL OutIntPartnerAllCase10 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);

                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:11

                                cmd.CommandText = "CALL OutIntPartnerAllCase11 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:12

                                cmd.CommandText = "CALL OutIntPartnerAllCase12 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:13

                                cmd.CommandText = "CALL OutIntPartnerAllCase13 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:14

                                cmd.CommandText = "CALL OutIntPartnerAllCase14 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:15

                                cmd.CommandText = "CALL OutIntPartnerAllCase15 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:16

                                cmd.CommandText = "CALL OutIntPartnerAllCase16 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:17

                                cmd.CommandText = "CALL OutIntPartnerAllCase17 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:18

                                cmd.CommandText = "CALL OutIntPartnerAllCase18 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ONE

                    //********prefix

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutIntPartnerAllCase19 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutIntPartnerAllCase20 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutIntPartnerAllCase21 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutIntPartnerAllCase22 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutIntPartnerAllCase23 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutIntPartnerAllCase24 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutIntPartnerAllCase25 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutIntPartnerAllCase26 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutIntPartnerAllCase27 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutIntPartnerAllCase28 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutIntPartnerAllCase29 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutIntPartnerAllCase30 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutIntPartnerAllCase31 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutIntPartnerAllCase32 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutIntPartnerAllCase33 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutIntPartnerAllCase34 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutIntPartnerAllCase35 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutIntPartnerAllCase36 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }
                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************



                    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ONE***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase19 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase20 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase21 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase22 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase23 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase24 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase25 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase26 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase27 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase28 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase29 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase30 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase31 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase32 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase33 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase34 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase35 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutIntPartnerAllOneCountryCase36 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }


                }//IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER ALL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


                //IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER One^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                if ((CheckBoxIntlPartner.Checked == true) && (DropDownListIntlCarier.SelectedValue != "-1"))
                {
                    //By Country Only, GROUP BY COUNTRY=ALL
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:1

                                cmd.CommandText = "CALL OutIntPartnerOneCase1 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:2

                                cmd.CommandText = "CALL OutIntPartnerOneCase2 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";



                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:3

                                cmd.CommandText = "CALL OutIntPartnerOneCase3 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:4

                                cmd.CommandText = "CALL OutIntPartnerOneCase4 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:5

                                cmd.CommandText = "CALL OutIntPartnerOneCase5 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:6

                                cmd.CommandText = "CALL OutIntPartnerOneCase6 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:7

                                cmd.CommandText = "CALL OutIntPartnerOneCase7 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:8

                                cmd.CommandText = "CALL OutIntPartnerOneCase8 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:9

                                cmd.CommandText = "CALL OutIntPartnerOneCase9 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ALL

                    //*************************************************************************************
                    //By Country Only, GROUP BY COUNTRY=ONE
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:10

                                cmd.CommandText = "CALL OutIntPartnerOneCase10 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";

                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);

                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:11

                                cmd.CommandText = "CALL OutIntPartnerOneCase11 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:12

                                cmd.CommandText = "CALL OutIntPartnerOneCase12 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:13

                                cmd.CommandText = "CALL OutIntPartnerOneCase13 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:14

                                cmd.CommandText = "CALL OutIntPartnerOneCase14 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:15

                                cmd.CommandText = "CALL OutIntPartnerOneCase15 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:16

                                cmd.CommandText = "CALL OutIntPartnerOneCase16 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:17

                                cmd.CommandText = "CALL OutIntPartnerOneCase17 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:18

                                cmd.CommandText = "CALL OutIntPartnerOneCase18 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ONE

                    //********prefix

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutIntPartnerOneCase19 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutIntPartnerOneCase20 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutIntPartnerOneCase21 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutIntPartnerOneCase22 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutIntPartnerOneCase23 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutIntPartnerOneCase24 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutIntPartnerOneCase25 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutIntPartnerOneCase26 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutIntPartnerOneCase27 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutIntPartnerOneCase28 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutIntPartnerOneCase29 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutIntPartnerOneCase30 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutIntPartnerOneCase31 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutIntPartnerOneCase32 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutIntPartnerOneCase33 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutIntPartnerOneCase34 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutIntPartnerOneCase35 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutIntPartnerOneCase36 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }
                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************



                    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ONE***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase19 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase20 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase21 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase22 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase23 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase24 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase25 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase26 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase27 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase28 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase29 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase30 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase31 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase32 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase33 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase34 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase35 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutIntPartnerOneOneCountryCase36 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }


                }//IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER One^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

            }//^^^^^^^^^^^*********&&&&&&&&&&&&&&&& if checkbox view by destination is checked

            else //no prefix or country wise group by
            {

                GridView1.Columns[1].Visible = false;
                GridView1.Columns[2].Visible = false;

                //IF GROUP BY INTERNATIONAL PARTNER=FALSE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                if (CheckBoxIntlPartner.Checked == false)
                {
                    //By Country Only, GROUP BY COUNTRY=ALL
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:1

                                cmd.CommandText = "CALL OutNoDestIntCase1 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:2

                                cmd.CommandText = "CALL OutNoDestIntCase2 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:3

                                cmd.CommandText = "CALL OutNoDestIntCase3 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:4

                                cmd.CommandText = "CALL OutNoDestIntCase4 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:5

                                cmd.CommandText = "CALL OutNoDestIntCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                cmd.CommandText = "CALL SummaryOutNoDestIntCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:6

                                cmd.CommandText = "CALL OutNoDestIntCase6 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:7

                                cmd.CommandText = "CALL OutNoDestIntCase7 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:8

                                cmd.CommandText = "CALL OutNoDestIntCase8 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:9

                                cmd.CommandText = "CALL OutNoDestIntCase9 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ALL

                    //*************************************************************************************
                    //By Country Only, GROUP BY COUNTRY=ONE
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:10

                                cmd.CommandText = "CALL OutNoDestIntCase10 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);

                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:11

                                cmd.CommandText = "CALL OutNoDestIntCase11 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:12

                                cmd.CommandText = "CALL OutNoDestIntCase12 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:13

                                cmd.CommandText = "CALL OutNoDestIntCase13 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:14

                                cmd.CommandText = "CALL OutNoDestIntCase14 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:15

                                cmd.CommandText = "CALL OutNoDestIntCase15 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:16

                                cmd.CommandText = "CALL OutNoDestIntCase16 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:17

                                cmd.CommandText = "CALL OutNoDestIntCase17 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:18

                                cmd.CommandText = "CALL OutNoDestIntCase18 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ONE

                    //********prefix

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutNoDestIntCase19 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutNoDestIntCase20 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutNoDestIntCase21 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutNoDestIntCase22 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutNoDestIntCase23 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutNoDestIntCase24 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutNoDestIntCase25 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutNoDestIntCase26 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutNoDestIntCase27 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutNoDestIntCase28 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutNoDestIntCase29 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutNoDestIntCase30 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutNoDestIntCase31 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutNoDestIntCase32 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutNoDestIntCase33 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutNoDestIntCase34 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutNoDestIntCase35 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutNoDestIntCase36 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }
                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************



                    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ONE***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase19 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase20 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase21 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase22 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase23 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase24 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase25 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase26 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase27 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase28 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase29 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase30 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase31 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase32 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase33 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase34 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase35 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutNoDestIntOneCountryCase36 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }


                }//IF GROUP BY INTERNATIONAL PARTNER=FALSE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


                //IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER ALL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                if ((CheckBoxIntlPartner.Checked == true) && (DropDownListIntlCarier.SelectedValue == "-1"))
                {
                    //By Country Only, GROUP BY COUNTRY=ALL
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:1

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase1 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:2

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase2 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:3

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase3 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:4

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase4 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:5

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                cmd.CommandText = "CALL SummaryOutNoDestIntPartnerAllCase5 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:6

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase6 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";



                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:7

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase7 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:8

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase8 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:9

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase9 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ALL

                    //*************************************************************************************
                    //By Country Only, GROUP BY COUNTRY=ONE
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:10

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase10 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);

                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:11

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase11 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:12

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase12 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:13

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase13 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:14

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase14 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:15

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase15 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:16

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase16 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:17

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase17 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:18

                                cmd.CommandText = "CALL OutNoDestIntPartnerAllCase18 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ONE

                    //********prefix

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase19 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase20 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase21 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase22 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase23 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase24 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase25 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase26 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase27 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase28 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase29 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase30 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase31 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase32 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase33 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase34 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase35 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllCase36 (@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }
                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************



                    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ONE***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase19 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase20 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase21 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase22 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase23 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase24 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase25 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase26 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase27 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase28 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase29 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase30 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase31 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase32 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase33 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase34 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase35 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutNoDestIntPartnerAllOneCountryCase36 (@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }


                }//IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER ALL^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


                //IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER One^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                if ((CheckBoxIntlPartner.Checked == true) && (DropDownListIntlCarier.SelectedValue != "-1"))
                {
                    //By Country Only, GROUP BY COUNTRY=ALL
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:1

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase1 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:2

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase2 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";



                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:3

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase3 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));
                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:4

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase4 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:5

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase5 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:6

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase6 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:7

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase7 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:8

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase8 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:9

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase9 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ALL

                    //*************************************************************************************
                    //By Country Only, GROUP BY COUNTRY=ONE
                    if ((CheckBoxShowByCountry.Checked == true) && (CheckBoxShowByDestination.Checked==false) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //Group by IGW=false
                        if (CheckBoxShowByIgw.Checked == false)
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:10

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase10 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);

                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:11

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase11 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:12

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase12 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ALL
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:13

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase13 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:14

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase14 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:15

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase15 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                        //Group by IGW=true, BY IGW ONE
                        if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                        {
                            //Group by Ans=False
                            if (CheckBoxShowByAns.Checked == false)
                            {
                                //CASE:16

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase16 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ALL
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                            {
                                //CASE:17

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase17 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                            //Group by Ans=True, BY ANS ONE
                            if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                            {
                                //CASE:18

                                cmd.CommandText = "CALL OutNoDestIntPartnerOneCase18 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_CountryCode)";


                                cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                            }
                        }
                    }//if BY COUNtRY ONLY, GROUP BY COUNTRY=ONE

                    //********prefix

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue == "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase19 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase20 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase21 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase22 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase23 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase24 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase25 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase26 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase27 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase28 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase29 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase30 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase31 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase32 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase33 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase34 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase35 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneCase36 (@p_IntlPartner,@p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }
                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************



                    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                    //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ONE***************************
                    if ((NotViewingByCountry == true) && (DropDownListCountry.SelectedValue != "-1"))
                    {
                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************

                        //By Prefix, GROUP BY PREFIX=ALL
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue == "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:19

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase19 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:20

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase20 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:21

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase21 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:22

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase22 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:23

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase23 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:24

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase24 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:25

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase25 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:26

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase26 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:27

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase27 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ALL

                        //By Prefix, GROUP BY PREFIX=ONE
                        if ((NotViewingByCountry == true) && (DropDownPrefix.SelectedValue != "-1"))
                        {
                            //Group by IGW=false
                            if (CheckBoxShowByIgw.Checked == false)
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:28

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase28 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:29

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase29 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);

                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:30
                                    //CASE:30

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase30 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ALL
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue == "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:31
                                    //CASE:31

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase31 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:32
                                    //CASE:32

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase32 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:33
                                    //CASE:33

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase33 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                            //Group by IGW=true, BY IGW ONE
                            if ((CheckBoxShowByIgw.Checked == true) && (DropDownListIgw.SelectedValue != "-1"))
                            {
                                //Group by Ans=False
                                if (CheckBoxShowByAns.Checked == false)
                                {
                                    //CASE:34
                                    //CASE:34

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase34 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ALL
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue == "-1"))
                                {
                                    //CASE:35
                                    //CASE:35

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase35 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                                //Group by Ans=True, BY ANS ONE
                                if ((CheckBoxShowByAns.Checked == true) && (DropDownListAns.SelectedValue != "-1"))
                                {
                                    //CASE:36
                                    //CASE:36

                                    cmd.CommandText = "CALL OutNoDestIntPartnerOneOneCountryCase36 (@p_IntlPartner,@p_CountryCode, @p_UsdRateY,@p_StartDateTime,@p_EndDateTime,@p_AnsId,@p_IgwId,@p_MatchedPrefixY)";


                                    cmd.Parameters.AddWithValue("p_IntlPartner", int.Parse(DropDownListIntlCarier.SelectedValue));

                                    cmd.Parameters.AddWithValue("p_CountryCode", DropDownListCountry.SelectedValue);
                                    cmd.Parameters.AddWithValue("p_UsdRateY", Single.Parse(TextBoxUsdRate.Text));
                                    cmd.Parameters.AddWithValue("p_StartDateTime", txtDate.Text);
                                    cmd.Parameters.AddWithValue("p_EndDateTime", txtDate1.Text);
                                    cmd.Parameters.AddWithValue("p_AnsId", Int32.Parse(DropDownListAns.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_IgwId", int.Parse(DropDownListIgw.SelectedValue));
                                    cmd.Parameters.AddWithValue("p_MatchedPrefixY", DropDownPrefix.SelectedValue);
                                }
                            }
                        }//if BY prefix, GROUP BY PREFIX=ONE

                        //&&&&&&&& NOT GROUP BY COUNTRY BUT PREFIX FOR COUNTRY= ALL***************************
                    }


                }//IF GROUP BY INTERNATIONAL PARTNER=TRUE AND BY PARTNER One^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

            }



            //Common Code**************#########################################
            Label1.Text = "";
            //this piece of code is important, reqport queries don't have date column when not summarized by day/hour etc.
            //need to hide gridview column[0] at times then
            if (RadioButtonHalfHourly.Checked == false)
            {

                GridView1.Columns[0].Visible = false;
            }
            else
            {
                GridView1.Columns[0].Visible = true;

            }


            //common code
            if (RadioButtonHalfHourly.Checked == true)
            {
                string SummaryInterval = "";
                if (RadioButtonHalfHourly.Checked == true)
                {
                    SummaryInterval = "Halfhourly";
                    GridView1.Columns[0].HeaderText = "Half Hour";
                }
                else if (RadioButtonHourly.Checked == true)
                {
                    SummaryInterval = "Hourly";
                    GridView1.Columns[0].HeaderText = "Hour";
                }
                else if (RadioButtonDaily.Checked == true)
                {
                    SummaryInterval = "Daily";
                    GridView1.Columns[0].HeaderText = "Date";
                }
                else if (RadioButtonWeekly.Checked == true)
                {
                    SummaryInterval = "Weekly";
                    GridView1.Columns[0].HeaderText = "Week";
                }
                else if (RadioButtonMonthly.Checked == true)
                {
                    SummaryInterval = "Monthly";
                    GridView1.Columns[0].HeaderText = "Month";
                }
                else if (RadioButtonYearly.Checked == true)
                {
                    SummaryInterval = "Yearly";
                    GridView1.Columns[0].HeaderText = "Year";
                }

                cmd.CommandText = cmd.CommandText.Replace("CALL ", "CALL " + SummaryInterval + "Summary");

            }

            //source for report... cdr or summary data
            switch (DropDownListReportSource.SelectedValue)
            {
                case "1"://CDR
                    break;
                case "2"://Summary Data
                    cmd.CommandText = cmd.CommandText.Replace("CALL ", "CALL SD");
                    break;
                case "3"://Cdr Error
                    cmd.CommandText = cmd.CommandText.Replace("CALL ", "CALL Err");
                    break;
            }


            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataSet dataset = new DataSet();
            da.Fill(dataset);

            dt = dataset.Tables[0];
            Session["InternationalOut.aspx.csdt17"] = dataset; //THIS MUST BE CHANGED FOR EACH PAGE

            GridView1.DataSource = dataset;
            bool hasRows = dataset.Tables.Cast<DataTable>()
                               .Any(table => table.Rows.Count != 0);

            if (hasRows == true)
            {
                Label1.Text = "";
                Button1.Visible = true; //show export
                GridView1.ShowFooter = true;//set it here before setting footer text, setting this to true clears already set footer text
                Label1.Text = "";
                Button1.Visible = true; //show export
                //Summary calculation for grid view*************************
                TrafficReportDatasetBased tr = new TrafficReportDatasetBased(dataset);
                tr.ds = dataset;
                List<NoOfCallsVsPDD> callVsPdd = new List<NoOfCallsVsPDD>();
                foreach (DataRow dr in tr.ds.Tables[0].Rows)
                {
                    tr.callStat.TotalCalls += tr.ForceConvertToLong(dr["CallsCount"]);
                    tr.callStat.ConnectedCalls += tr.ForceConvertToLong(dr["ConnectedCount"]);
                    tr.callStat.ConnectedCallsbyCauseCodes += tr.ForceConvertToLong(dr["ConnectByCC"]);
                    tr.callStat.SuccessfullCalls += tr.ForceConvertToLong(dr["No of Calls (Outgoing International)"]);
                    tr.callStat.TotalActualDuration += tr.ForceConvertToDouble(dr["Paid Minutes (Outgoing Internaitonal)"]);
                    tr.callStat.TotalRoundedDuration += tr.ForceConvertToDouble(dr["RoundedDuration"]);
                    tr.callStat.TotalDuration3 += tr.ForceConvertToDouble(dr["hmsduration"]);
                    tr.callStat.TotalDuration2 += tr.ForceConvertToDouble(dr["supplierduration"]);
                    tr.callStat.igwRevenue+= tr.ForceConvertToDouble(dr["revenueigwout"]);
                    tr.callStat.supplierCost += tr.ForceConvertToDouble(dr["suppliercost"]);
                    tr.callStat.profitBdt += tr.ForceConvertToDouble(dr["profitbdt"]);

                    NoOfCallsVsPDD cpdd = new NoOfCallsVsPDD(tr.ForceConvertToLong(dr["No of Calls (Outgoing International)"]), tr.ForceConvertToDouble(dr["PDD"]));
                    callVsPdd.Add(cpdd);
                }
                tr.callStat.TotalActualDuration = Math.Round(tr.callStat.TotalActualDuration, 2);
                tr.callStat.TotalDuration1 = Math.Round(tr.callStat.TotalDuration1, 2);
                tr.callStat.TotalDuration2 = Math.Round(tr.callStat.TotalDuration2, 2);
                tr.callStat.TotalDuration3 = Math.Round(tr.callStat.TotalDuration3, 2);
                tr.callStat.TotalDuration4 = Math.Round(tr.callStat.TotalDuration4, 2);
                tr.callStat.TotalRoundedDuration = Math.Round(tr.callStat.TotalRoundedDuration, 2);
                tr.callStat.CalculateASR(2);
                tr.callStat.CalculateACD(2);
                tr.callStat.CalculateAveragePDD(callVsPdd, 2);
                tr.callStat.CalculateCCR(2);
                tr.callStat.CalculateCCRbyCauseCode(2);
                tr.callStat.CalculateProfitPerMinute(2);
                //SUMMARY CALCULATION FOR GRIDVIEW COMPLETE


                //display summary information in the footer
                Dictionary<string, dynamic> fieldSummaries = new Dictionary<string, dynamic>();//key=colname,val=colindex in grid
                //all keys have to be lowercase, because db fields are lower case at times
                fieldSummaries.Add("callscount", tr.callStat.TotalCalls);
                fieldSummaries.Add("connectedcount", tr.callStat.ConnectedCalls);
                fieldSummaries.Add("connectbycc", tr.callStat.ConnectedCallsbyCauseCodes);
                fieldSummaries.Add("no of calls (outgoing international)", tr.callStat.SuccessfullCalls);
                fieldSummaries.Add("paid minutes (outgoing internaitonal)", tr.callStat.TotalActualDuration);
                fieldSummaries.Add("roundedduration", tr.callStat.TotalRoundedDuration);
                fieldSummaries.Add("hmsduration", tr.callStat.TotalDuration3);
                fieldSummaries.Add("supplierduration", tr.callStat.TotalDuration2);
                fieldSummaries.Add("asr", tr.callStat.ASR);
                fieldSummaries.Add("acd", tr.callStat.ACD);
                fieldSummaries.Add("pdd", tr.callStat.PDD);
                fieldSummaries.Add("ccr", tr.callStat.CCR);
                fieldSummaries.Add("ccrbycc", tr.callStat.CCRbyCauseCode);
                tr.fieldSummaries = fieldSummaries;

                Session["IntlOut"] = tr;//save to session

                //populate footer
                //clear first
                bool CaptionSetForTotal = false;
                for (int c = 0; c < GridView1.Columns.Count; c++)
                {
                    GridView1.Columns[c].FooterText = "";
                }
                for (int c = 0; c < GridView1.Columns.Count; c++)
                {
                    if (CaptionSetForTotal == false && GridView1.Columns[c].Visible == true)
                    {
                        GridView1.Columns[c].FooterText = "Total: ";//first visible column
                        CaptionSetForTotal = true;
                    }
                    string key = GridView1.Columns[c].SortExpression.ToLower();
                    if (key == "") continue;
                    if (tr.fieldSummaries.ContainsKey(key))
                    {
                        GridView1.Columns[c].FooterText += (tr.GetDataColumnSummary(key)).ToString();//+ required to cocat "Total:"
                    }
                }
                GridView1.DataBind();//call it here after setting footer, footer text doesn't show sometime otherwise, may be a bug
                GridView1.ShowFooter = true;//don't set it now, set before footer text setting, weird! it clears the footer text

                //hide filters...
                Page.ClientScript.RegisterStartupScript(GetType(), "MyKey", "HideParamBorderDivSubmit();", true);
                hidValueSubmitClickFlag.Value = "false";


            }//if has rows=true
            else
            {
                GridView1.DataBind();
                Label1.Text = "No Data!";
                Button1.Visible = false; //hide export
            }





        }//using mysql connection

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Session["IntlOut"] != null) //THIS MUST BE CHANGED IN EACH PAGE
        {
            TrafficReportDatasetBased tr = (TrafficReportDatasetBased)Session["IntlOut"];
            DataSetWithGridView dsG = new DataSetWithGridView(tr, GridView1);//invisible columns are removed in constructor
            CreateExcelFileAspNet.CreateExcelDocumentAsStreamEpPlusPackageLastRowSummary(tr.ds, "IntlOutgoing_" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    + ".xlsx", Response);
        }

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //load prefix dropdown combo
        string PrefixFilter = "-1";
        if (DropDownListCountry.SelectedValue != "")//avoid executing during initial page load when selected value is not set
        {
            PrefixFilter = DropDownListCountry.SelectedValue;
        }
        
        using (MySqlConnection Con = new MySqlConnection(ConfigurationManager.ConnectionStrings["reader"].ConnectionString))
        {
            Con.Open();
            using (MySqlCommand cmd = new MySqlCommand("", Con))
            {
                cmd.CommandText = "CALL OutgoingPrefix(@p_CountryCode)";
                cmd.Parameters.AddWithValue("p_CountryCode", PrefixFilter);

                MySqlDataReader dr = cmd.ExecuteReader();
                DropDownPrefix.Items.Clear();
                while (dr.Read())
                {
                    DropDownPrefix.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
                }
            }
        }
    }


    protected void CheckBoxShowByPartner_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxIntlPartner.Checked == true)
        {
            DropDownListIntlCarier.Enabled = true;
            //GridView1.Columns[3].Visible = true;
        }
        else
        {
            DropDownListIntlCarier.Enabled = false;
            DropDownListIntlCarier.SelectedIndex = 0;
            //GridView1.Columns[3].Visible = false;
        }
    }


    protected void CheckBoxShowByAns_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxShowByAns.Checked == true)
        {
            DropDownListAns.Enabled = true;
            //GridView1.Columns[3].Visible = true;
        }
        else
        {
            DropDownListAns.Enabled = false;
            DropDownListAns.SelectedIndex = 0;
            //GridView1.Columns[3].Visible = false;
        }
    }
    protected void CheckBoxShowByIgw_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxShowByIgw.Checked == true)
        {
            DropDownListIgw.Enabled = true;
            //GridView1.Columns[4].Visible = true;
        }
        else
        {
            DropDownListIgw.Enabled = false;
            DropDownListIgw.SelectedIndex = 0;
            //GridView1.Columns[4].Visible = false;
        }
    }
    protected void CheckBoxShowByCountry_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxShowByCountry.Checked == true)
        {
            DropDownPrefix.SelectedIndex = 0;
            //DropDownPrefix.Enabled = false;

            DropDownListCountry.SelectedIndex = 0;
            DropDownListCountry.Enabled = true;
            // GridView1.Columns[2].Visible = false; //prefix

            CheckBoxShowByDestination.Checked = false;

        }
        else
        {
            //DropDownPrefix.Enabled = true;
            //GridView1.Columns[2].Visible = true;
            DropDownListCountry.SelectedIndex = 0;
            DropDownListCountry.Enabled = false;

            //load prefix dropdown combo
            string PrefixFilter = "-1";
            if (DropDownListCountry.SelectedValue != "")//avoid executing during initial page load when selected value is not set
            {
                PrefixFilter = DropDownListCountry.SelectedValue;
            }

            using (MySqlConnection Con = new MySqlConnection(ConfigurationManager.ConnectionStrings["reader"].ConnectionString))
            {
                Con.Open();
                using (MySqlCommand cmd = new MySqlCommand("", Con))
                {
                    cmd.CommandText = "CALL OutgoingPrefix(@p_CountryCode)";
                    cmd.Parameters.AddWithValue("p_CountryCode", PrefixFilter);

                    MySqlDataReader dr = cmd.ExecuteReader();
                    DropDownPrefix.Items.Clear();
                    while (dr.Read())
                    {
                        DropDownPrefix.Items.Add(new ListItem(dr[1].ToString(), dr[0].ToString()));
                    }
                }

            }
        }



    }

    protected void CheckBoxShowByDestination_CheckedChanged(object sender, EventArgs e)
    {
        


    }

    


    public static void ExportToSpreadsheet(DataTable table, string name)
    {
        HttpContext context = HttpContext.Current;
        context.Response.Clear();

        string ThisRow = "";
        foreach (DataColumn column in table.Columns)
        {

            ThisRow += column.ColumnName + ",";
        }
        ThisRow = ThisRow.Substring(0, ThisRow.Length - 1) + Environment.NewLine;
        context.Response.Write(ThisRow);


        foreach (DataRow row in table.Rows)
        {
            ThisRow = "";
            for (int i = 0; i < table.Columns.Count; i++)
            {

                ThisRow += row[i].ToString().Replace(",", string.Empty) + ",";
                //context.Response.Write(row[i].ToString());
                //context.Response.Write(row[i]);
            }
            ThisRow = ThisRow.Substring(0, ThisRow.Length - 1) + Environment.NewLine;
            context.Response.Write(ThisRow);

        }
        //context.Response.ContentType = "text/csv";
        //context.Response.ContentType = "application/vnd.ms-excel";
        context.Response.ContentType = "application/ms-excel";
        context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + name + ".csv");
        context.Response.End();
    }


    private void dateInitialize()
    {
        if (CheckBoxRealTimeUpdate.Checked)
        {
            long a;
            if (!long.TryParse(TextBoxDuration.Text, out a))
            {
                // If Not Integer Clear Textbox text or you can also Undo() Last Operation :)

                TextBoxDuration.Text = "30";
                a = 30;
            }

            DateTime endtime = DateTime.Now;
            DateTime starttime = endtime.AddMinutes(a * (-1));
            txtDate1.Text = endtime.ToString("dd/MM/yyyy HH:mm:ss");
            txtDate.Text = starttime.ToString("dd/MM/yyyy HH:mm:ss");
            //return true;
        }
        else
        {
            txtDate.Text = System.DateTime.Now.ToString("dd/MM/yyyy");
            txtDate1.Text = System.DateTime.Now.ToString("dd/MM/yyyy");
        }
    }

    protected void CheckBoxRealTimeUpdate_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxRealTimeUpdate.Checked)
        {
            //Disable DailySummary,Destination, Dates& Months

            RadioButtonHalfHourly.Checked = false;
            RadioButtonHalfHourly.Enabled = false;

            CheckBoxShowByDestination.Checked = false;
            //CheckBoxShowByDestination.Enabled = false;

            TextBoxYear.Enabled = false;
            DropDownListMonth.Enabled = false;
            txtDate.Enabled = false;

            TextBoxYear1.Enabled = false;
            DropDownListMonth1.Enabled = false;
            txtDate1.Enabled = false;

            //Enable Timers,Duration,country
            CheckBoxShowByCountry.Checked = true;
            TextBoxDuration.Enabled = true;
            //TextBoxDuration.Text = "30";
            timerflag = true;



            //dateInitialize
        }
        else
        {
            //Enable DailySummary,Destination, Dates& Months

            RadioButtonHalfHourly.Checked = true;
             RadioButtonHalfHourly.Enabled = true;

            CheckBoxShowByDestination.Checked = true;
            CheckBoxShowByDestination.Enabled = true;

            TextBoxYear.Enabled = true;
            DropDownListMonth.Enabled = true;
            txtDate.Enabled = true;

            TextBoxYear1.Enabled = true;
            DropDownListMonth1.Enabled = true;
            txtDate1.Enabled = true;

            //Disable Timers,Duration,
            //CheckBoxShowByCountry.Checked = false;
            TextBoxDuration.Enabled = false;
            //TextBoxDuration.Text = "30";
            timerflag = false;
        }
        CheckBoxShowByCountry_CheckedChanged(sender, e);
        dateInitialize();
    }

    protected void TextBoxDuration_TextChanged(object sender, EventArgs e)
    {
        long a;
        if (!long.TryParse(TextBoxDuration.Text, out a))
        {
            // If Not Integer Clear Textbox text or you can also Undo() Last Operation :)

            TextBoxDuration.Text = "30";
        }
    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {
        if (CheckBoxRealTimeUpdate.Checked)
        {
            submit_Click(sender, e);
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            return;
        }
        
        if (CheckBoxShowByCountry.Checked == true && (CheckBoxShowByDestination.Checked == false))
        {
            Dictionary<string, countrycode> dicKpiCountry = null;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (Session["dicKpiCountry"] != null)
                {
                    dicKpiCountry = (Dictionary<string, countrycode>)Session["dicKpiCountry"];
                }
                else
                {
                    return;
                }
                if (dicKpiCountry == null) return;
                //Label lblCountry = (Label)e.Row.FindControl("Label3");
                string ThisCountryName = DataBinder.Eval(e.Row.DataItem, "Country").ToString();
                
                string ThisCountryCode = "";
                int PosBracket = ThisCountryName.IndexOf("(");
                int PosBracketEnd = ThisCountryName.IndexOf(")");
                if (PosBracket > -1 && PosBracketEnd > -1)
                {
                    ThisCountryCode = ThisCountryName.Substring(PosBracket + 1, PosBracketEnd-PosBracket-1);
                }
                else
                {
                    return;
                }
                if (ThisCountryCode == "") return;
                
                Single ThisASR = 0;
                Single ThisACD = 0;
                Single ThisCCR = 0;
                Single ThisPDD = 0;
                Single ThisCCRbyCC = 0;
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "ASR").ToString(), out ThisASR);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "ACD").ToString(), out ThisACD);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "CCR").ToString(), out ThisCCR);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "PDD").ToString(), out ThisPDD);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "CCRByCC").ToString(), out ThisCCRbyCC);
                countrycode ThisCC = null;
                dicKpiCountry.TryGetValue(ThisCountryCode, out ThisCC);
                if (ThisCC != null)
                {
                    Color RedColor = ColorTranslator.FromHtml("#FF0000");
                    //ASR
                    Single RefAsr = 0;
                    if (Convert.ToSingle(ThisCC.refasr) > 0)
                    {
                        RefAsr = Convert.ToSingle(ThisCC.refasr);
                    }
                    if ((ThisASR < RefAsr) || (ThisASR == 0))
                    {
                        e.Row.Cells[13].ForeColor = Color.White;
                        e.Row.Cells[13].BackColor = RedColor;
                        e.Row.Cells[13].Font.Bold = true;
                    }

                    //fas detection
                    double RefAsrFas = RefAsr+RefAsr*.5;//fas threshold= 30% of ref asr by default
                    double TempDbl = 0;
                    double.TryParse(ThisCC.refasrfas.ToString(), out TempDbl);
                    if (TempDbl > 0) RefAsrFas = TempDbl;
                    
                    if (ThisASR > RefAsrFas && RefAsrFas>0)
                    {
                        e.Row.Cells[13].ForeColor = Color.White;
                        e.Row.Cells[13].BackColor = Color.Blue;
                        e.Row.Cells[13].Font.Bold = true;
                    }

                    //ACD
                    Single RefAcd = 0;
                    if (Convert.ToSingle(ThisCC.refacd) > 0)
                    {
                        RefAcd = Convert.ToSingle(ThisCC.refacd);
                    }
                    if (ThisACD < RefAcd)
                    {
                        //e.Row.Cells[12].ForeColor = RedColor;
                        e.Row.Cells[14].ForeColor = Color.White;
                        e.Row.Cells[14].BackColor = RedColor;
                        e.Row.Cells[14].Font.Bold = true;
                    }

                    //PDD
                    Single RefPdd = 0;
                    if (Convert.ToSingle(ThisCC.refpdd) > 0)
                    {
                        RefPdd = Convert.ToSingle(ThisCC.refpdd);
                    }
                    if (ThisPDD > RefPdd)
                    {
                        //e.Row.Cells[13].ForeColor = RedColor;
                        e.Row.Cells[15].ForeColor = Color.White;
                        e.Row.Cells[15].BackColor = RedColor;
                        e.Row.Cells[15].Font.Bold = true;
                    }

                    //CCR
                    Single RefCcr = 0;
                    if (Convert.ToSingle(ThisCC.refccr) > 0)
                    {
                        RefCcr = Convert.ToSingle(ThisCC.refccr);
                    }
                    if (ThisCCR < RefCcr)
                    {
                        //e.Row.Cells[14].ForeColor = RedColor;
                        e.Row.Cells[16].ForeColor = Color.White;
                        e.Row.Cells[16].BackColor = RedColor;
                        e.Row.Cells[16].Font.Bold = true;
                    }

                    //CCRByCauseCode
                    Single RefCcrCC = 0;
                    if (Convert.ToSingle(ThisCC.refccrbycc) > 0)
                    {
                        RefCcrCC = Convert.ToSingle(ThisCC.refccrbycc);
                    }
                    if (ThisCCRbyCC < RefCcrCC)
                    {
                        //e.Row.Cells[16].ForeColor = RedColor;
                        e.Row.Cells[18].ForeColor = Color.White;
                        e.Row.Cells[18].BackColor = RedColor;
                        e.Row.Cells[18].Font.Bold = true;
                    }
                }
            }



        }//if checkbox Country

        if (CheckBoxShowByDestination.Checked == true) //KPI by Destination
        {   
            Dictionary<string, xyzprefix> dicKpiDest = null;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (Session["dicKpiDest"] != null)
                {
                    dicKpiDest = (Dictionary<string, xyzprefix>)Session["dicKpiDest"];
                }
                else
                {
                    return;
                }
                if (dicKpiDest == null) return;
                //Label lblCountry = (Label)e.Row.FindControl("Label3");
                string ThisDestName = DataBinder.Eval(e.Row.DataItem, "Destination").ToString();

                string ThisDestCode = "";
                int PosBracket = ThisDestName.IndexOf("(");
                if (PosBracket > -1)
                {
                    ThisDestCode = ThisDestName.Substring(0, PosBracket - 1);
                }
                else
                {
                    return;
                }
                if (ThisDestCode == "") return;

                Single ThisASR = 0;
                Single ThisACD = 0;
                Single ThisCCR = 0;
                Single ThisPDD = 0;
                Single ThisCCRbyCC = 0;
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "ASR").ToString(), out ThisASR);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "ACD").ToString(), out ThisACD);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "CCR").ToString(), out ThisCCR);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "PDD").ToString(), out ThisPDD);
                Single.TryParse(DataBinder.Eval(e.Row.DataItem, "CCRByCC").ToString(), out ThisCCRbyCC);
                xyzprefix ThisDC = null;
                dicKpiDest.TryGetValue(ThisDestCode, out ThisDC);
                if (ThisDC != null)
                {
                    Color RedColor = ColorTranslator.FromHtml("#FF0000");
                    //ASR
                    Single RefAsr = 0;
                    if (Convert.ToSingle(ThisDC.refasr) > 0)
                    {
                        RefAsr = Convert.ToSingle(ThisDC.refasr);
                    }
                    if ((ThisASR < RefAsr) || (ThisASR == 0))
                    {
                        //e.Row.Cells[12].ForeColor = RedColor;
                        e.Row.Cells[13].ForeColor = Color.White;
                        e.Row.Cells[13].BackColor = RedColor;
                        e.Row.Cells[13].Font.Bold = true;
                    }

                    //fas detection
                    double TempDbl = 0;
                    double RefAsrFas = RefAsr + RefAsr * .5;//fas threshold= 30% of ref asr by default
                    double.TryParse(ThisDC.refasrfas.ToString(), out TempDbl);
                    if (TempDbl > 0) RefAsrFas = TempDbl;

                    if (ThisASR > RefAsrFas && RefAsrFas>0)
                    {
                        e.Row.Cells[13].ForeColor = Color.White;
                        e.Row.Cells[13].BackColor = Color.Blue;
                        e.Row.Cells[13].Font.Bold = true;
                    }

                    //ACD
                    Single RefAcd = 0;
                    if (Convert.ToSingle(ThisDC.refacd) > 0)
                    {
                        RefAcd = Convert.ToSingle(ThisDC.refacd);
                    }
                    if (ThisACD < RefAcd)
                    {
                        //e.Row.Cells[13].ForeColor = RedColor;
                        e.Row.Cells[14].ForeColor = Color.White;
                        e.Row.Cells[14].BackColor = RedColor;
                        e.Row.Cells[14].Font.Bold = true; 
                    }

                    //PDD
                    Single RefPdd = 0;
                    if (Convert.ToSingle(ThisDC.refpdd) > 0)
                    {
                        RefPdd = Convert.ToSingle(ThisDC.refpdd);
                    }
                    if (ThisPDD > RefPdd)
                    {
                        e.Row.Cells[15].ForeColor = Color.White;
                        e.Row.Cells[15].BackColor = RedColor;
                        e.Row.Cells[15].Font.Bold = true ;
                    }

                    //CCR
                    Single RefCcr = 0;
                    if (Convert.ToSingle(ThisDC.refccr) > 0)
                    {
                        RefCcr = Convert.ToSingle(ThisDC.refccr);
                    }
                    if (ThisCCR < RefCcr)
                    {
                        e.Row.Cells[16].ForeColor = Color.White;
                        e.Row.Cells[16].BackColor = RedColor;
                        e.Row.Cells[16].Font.Bold = true ;
                    }

                    //CCRByCauseCode
                    Single RefCcrCC = 0;
                    if (Convert.ToSingle(ThisDC.refccrbycc) > 0)
                    {
                        RefCcrCC = Convert.ToSingle(ThisDC.refccrbycc);
                    }
                    if (ThisCCRbyCC < RefCcrCC)
                    {
                        e.Row.Cells[18].ForeColor = Color.White;
                        e.Row.Cells[18].BackColor = RedColor;
                        e.Row.Cells[18].Font.Bold = true;
                    }
                }
            }



        }//if checkbox Destination

        //0 ASR highlighting
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            double ASR = 1;
            double.TryParse(e.Row.Cells[11].Text, out ASR);
            Color RedColor2 = ColorTranslator.FromHtml("#FF0000");
            if (ASR <= 0)
            {
                e.Row.Cells[13].ForeColor = Color.White;
                e.Row.Cells[13].BackColor = RedColor2;
                e.Row.Cells[13].Font.Bold = true;
            }
        }

    }
    
}
